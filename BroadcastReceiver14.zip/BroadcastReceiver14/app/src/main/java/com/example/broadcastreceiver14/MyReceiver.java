package com.example.broadcastreceiver14;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.util.Log;
import android.widget.Toast;

public class MyReceiver extends BroadcastReceiver {

    private static final String TAG ="123" ;

    @Override
    public void onReceive(Context context, Intent intent) {

        String actionString=intent.getAction();
        Toast.makeText(context, actionString, Toast.LENGTH_SHORT).show();
    }
}