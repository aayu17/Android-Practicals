package com.example.notification_14;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.os.Build;
import android.support.annotation.RequiresApi;
import android.support.v4.app.NotificationCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    Button b1;
    NotificationManager nm;
    public final String NOTIFICATION_ID="1";
    public final String NOTIFICATION_NAME="Example";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        b1=findViewById(R.id.button);
        nm=(NotificationManager)getSystemService(NOTIFICATION_SERVICE);

        if(Build.VERSION.SDK_INT>=Build.VERSION_CODES.O)
        {
            createNotificationChannel();
        }

        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                NotificationCompat.Builder builder=new NotificationCompat.Builder(getApplicationContext(),NOTIFICATION_ID)
                        .setSmallIcon(R.drawable.logo)
                        .setContentTitle("Next Coders")
                        .setPriority(NotificationCompat.PRIORITY_DEFAULT)
                        .setContentText("Follow Next Coders For Programming Content");
                nm.notify(1,builder.build());
            }
        });


    }
    @RequiresApi(api = Build.VERSION_CODES.O)
    private void createNotificationChannel() {
        NotificationChannel nc= new NotificationChannel(NOTIFICATION_ID,NOTIFICATION_NAME, NotificationManager.IMPORTANCE_DEFAULT);
        nm.createNotificationChannel(nc);
    }
}