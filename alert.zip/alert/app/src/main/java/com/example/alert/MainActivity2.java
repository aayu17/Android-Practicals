package com.example.alert;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity2 extends AppCompatActivity {
    TextView text;
    TextView text2;
    Button logout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        Intent i=getIntent();
        text=findViewById(R.id.textView);
        text2=findViewById(R.id.textView2);
        logout=findViewById(R.id.button2);
        String str1 = i.getStringExtra("KEY1");
        String str2 = i.getStringExtra("KEY2");
        text.setText("Welcome : " +str1);
//        text2.setText("Password : " +str2);

        logout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                    alert("Do YOU U WANT TO EXIT");
            }
        });
    }
    private void alert(String msg)
    {
        AlertDialog dlg=new AlertDialog.Builder(MainActivity2.this)
                .setTitle("PLEASE CONFIRM")
                .setMessage(msg)
                .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        Intent intent=new Intent(MainActivity2.this,MainActivity.class);
                       startActivity(intent);
                    }
                })
                .setNegativeButton("NO", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        dialogInterface.dismiss();
                    }
                })
                .create();
        dlg.show();
    }
}